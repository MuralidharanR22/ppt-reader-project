package com.tasks.pptReaderProject.service;

import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

public interface pptUploadService {

	public Map<String, Object> parsePpt(MultipartFile file);
}
