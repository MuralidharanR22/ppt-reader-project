package com.tasks.pptReaderProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PptReaderProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
